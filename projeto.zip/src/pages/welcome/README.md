# Welcome

Welcome is a splash screen that displays some info about the app and directs the usuario to log in our create an account.
