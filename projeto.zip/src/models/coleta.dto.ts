export interface ColetaDTO {
    id: string;
    dataAgendamento: Date;
    material: string;
    observacao: string;
    situacao: string;
    idCliente: string
}