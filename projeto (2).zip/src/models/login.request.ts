export interface LoginRequest {
    email: string;
    senha: string
}