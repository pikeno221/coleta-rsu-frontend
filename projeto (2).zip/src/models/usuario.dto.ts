export interface UsuarioDTO {
    id: string;
    nomeCompleto: string;
    email: string;
    senha: string;
    celular: string;
    endereco: string;
    statusUsuario: string;
    tipoPessoa: string
}