import { UsuarioDTO } from "./usuario.dto";

export class LoginResponse {
    mensagem: string;
    sucesso: boolean;
    usuario: UsuarioDTO;
}




  